// Email Configuration
// Priority: 1) Environment variables (.env file), 2) Fallback hardcoded values

export const emailConfig = {
  EMAIL_USER: 'rahulkirad.byline@gmail.com',
  EMAIL_PASS: 'hzrekxezlhdiyyuh',
  EMAIL_HOST: 'smtp.gmail.com',
  EMAIL_PORT: 587,
  EMAIL_FROM: 'rahulkirad.byline@gmail.com'
};
